# Step 6 - Generating principal component for modeling population stratification

#Set LD threshold to 0.2
ld.thresh<-0.2

set.seed(1000)
geno.sample.ids<- rownames(genotype)
snpSUB<- snpgdsLDpruning(genofile, ld.threshold = ld.thresh,
                         sample.id = geno.sample.ids, #Only analyze the filted samples
                         snp.id = colnames(genotype)) #Only analyze the filtered SNPs

snpset.pca<- unlist(snpSUB, use.names = FALSE)
cat(length(snpset.pca),'\n')

pca<- snpgdsPCA(genofile, sample.id = geno.sample.ids, snp.id = snpset.pca, num.thread = 1)

# Find and record first 10 principal components
# pcs will in a N:10 matrix. Each column is a principal component.
pcs<- data.frame(FamID=pca$sample.id, pca$eigenvect[,1:10],
                 stringsAsFactors = FALSE)
colnames(pcs)[2:11]<-paste('pc', 1:10, sep='')

print(head(pcs))
