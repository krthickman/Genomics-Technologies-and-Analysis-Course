# Step 4 - Filter SNPs by kinship and linkage to diminish chromosomal artifacts

#set thresholds
ld.thresh <- 0.2 #threshold of linkage
kin.thresh <- 0.1 #threshold for kinship

#Create gdsfile requires for SNPRelate functions
snpgdsBED2GDS(gwas.fn$bed, gwas.fn$fam, gwas.fn$bim, gwas.fn$gds)
genofile <- snpgdsOpen(gwas.fn$gds, readonly = FALSE)

#Automatically added sample suffixes are removed
gds.ids <- read.gdsn(index.gdsn(genofile, 'sample.id'))
gds.ids <- sub('-1', '', gds.ids)
add.gdsn(genofile, 'sample.id', gds.ids, replace=TRUE)

#Prune SNPs for IBD analysis
set.seed(1000)
geno.sample.ids <- rownames(genotype)
snpSUB <- snpgdsLDpruning(genofile, ld.threshold = ld.thresh,
                          sample.id = geno.sample.ids, #only analyze the filtered samples
                          snp.id= colnames(genotype))  #only analyze the fintered SNPs
snpset.ibd <- unlist(snpSUB, use.names = FALSE)
cat(length(snpset.ibd),'will be used in IBD analysis \n')

#Find IBD coeffiencts using the Methods of Moments procedure. Include pairwise kinship
ibd<- snpgdsIBDMoM(genofile, kinship = TRUE, sample.id = geno.sample.ids,
                   snp.id = snpset.ibd, num.thread = 1)
ibdcoeff <- snpgdsIBDSelection(ibd) #Pairwise sample comparison
head(ibdcoeff)

#Check if there are candidates for relatedness
ibdcoeff <- ibdcoeff[ibdcoeff$kinship >= kin.thresh,]

#iteratively remove samples with high kinship staarting with sample with the most pairings
related.samples <- NULL
while(nrow(ibdcoeff)>0){
  #count the number of occurrences of each and take the top one 
  sample.counts <- arrange(count(c(ibdcoeff$ID1, ibdcoeff$ID2)), -freq)
  rm.sample <- sample.counts[1,'x']
  cat('Removing sample', as.character(rm.sample), 'too closely related to', sample.counts[1,'freq'], 'other samples. \n')
  
  #remove for ibdcoeff and and to list
  ibdcoeff <- ibdcoeff[ibdcoeff$ID1 != rm.sample & idbcoeff$ID2 != rm.sample, ]
  related.samples <- c(as.characer(rm.sample), related.samples)
}

#filter genotype and clinical to include only unrelated samples
genotype <- genotype[!(rownames(genotype) %in% related.samples),]
clinical <- clinical[!(clinical$FamID %in% related.samples),]

geno.sample.ids<- rownames(genotype)

cat(length(related.samples), 'similar samples removed due to correlation coefficient >=', kin.thresh,'\n')
print(genotype)

# Check for ancestry

#Find PCA matrix
pca<- snpgdsPCA(genofile, sample.id = geno.sample.ids, snp.id = snpset.ibd, num.thread = 1)

#Create data frame of first two prinicpal components 
pctab<- data.frame(sample.id=pca$sample.id,
                   PC1=pca$eigenvect[,1],  #1st PC
                   PC2=pca$eigenvect[,2],  #2nd PC
                   stringsAsFactors = FALSE)

#Plot the first 2 PC
par(mar=rep(2,4))
plot(pctab$PC2, pctab$PC1, xlab='Principal Component 2', ylab='Principal Component 1', main='Ancestry Plot')


