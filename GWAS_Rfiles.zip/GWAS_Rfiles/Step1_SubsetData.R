# step1_ subset genotype for individuals with clinical data

print("beginning genotypes") 
print(genotype)
genotype<-genotype[clinical$FamID,]
print('ending genotypes') 
print(genotype)

#