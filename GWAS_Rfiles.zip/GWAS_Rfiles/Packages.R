#packages
# Run once to download and install Bioconductor and other packages

library(BiocInstaller)
biocLite("snpStats")
biocLite("SNPRelate")
biocLite('rtracklayer')
biocLite('biomaRt')
biocLite("plyr")
biocLite('GenABEL')
biocLite('LDheatmap')
biocLite('doParallel')
biocLite('ggplot2')
biocLite('coin')
biocLite('igraph')
biocLite('devtools')

library(devtools)
install_url("http://cran.r-project.org/src/contrib/Archive/postgwas/postgwas_1.11.tar.gz")
