#-- step 3 - sample level filtering
# filtering by individual for individuals with poor data quality

library(SNPRelate)
library(plyr)

#Create sample statistics (Call rate, heterozygosity)
snpsum.row <- row.summary(genotype)

# add the F stat (inbreeding coefficient) to snpsum.row
MAF <- snpsum.col$MAF
callmatrix <- !is.na(genotype)
hetExp <- callmatrix %*% (2*MAF*(1-MAF))
hetObs <- with(snpsum.row, Heterozygosity*(ncol(genotype))*Call.rate)
snpsum.row$hetF <- 1-(hetObs/hetExp)

head(snpsum.row)

#setting thresholds for filtering
sampcall <- 0.95  #sample cut off rate - at least 95% of SNPs have calls for the individual
hetcutoff <- 0.1  # inbreeding cut off. The F of hereozygosity is at least 10%

sampleuse <- with(snpsum.row, !is.na(Call.rate) & Call.rate >sampcall & abs(hetF)<= hetcutoff)
sampleuse[is.na(sampleuse)] <- FALSE
cat(nrow(genotype)-sum(sampleuse), 'subjects will be removed due to low sample call rate or inbreeding coefficient. \n')

#subset genotype and clinical data for subjects that do not pass the filtering
genotype <- genotype[sampleuse,]
clinical <- clinical[rownames(genotype),]

