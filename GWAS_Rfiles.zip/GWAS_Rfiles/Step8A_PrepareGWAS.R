#--Step 8- Association analysis of typed SNPs with HDL-cholesterol

library(GenABEL)
library(plyr)
library(doParallel)

genodata <- genotype
cat(paste(ncol(genodata),"SNPs included in analysis.\n"))

#create text file for GWAA output
columns<- c("SNP", 'Estimate', 'Std.Error','t-value','p-value')
write.table(t(columns), 'GWAA.txt', row.names=FALSE, col.names = FALSE, quote=FALSE)

#merge clinical data and prinical components to create a phenotype table
phenoSub<- merge(clinical,pcs) #data.frame +> [FamID CAD sex age hd1 pc1 pc2 ... pc 10]

#We will do a rank-based inverse normal transformation of hdl
phenoSub$phenotype <- rntransform(as.numeric(phenoSub$hdl, family = 'gaussian'))


#Show that the assumptions or normality are met after transformation
par(mfrow=c(1,2))
hist(phenoSub$hdl, main="Histogram of HDL", xlab="HDL")
hist(phenoSub$phenotype, main = 'Histogram of Transformed HDL', xlab="Transformed HDL")

#Remove unnecessary columns from table
phenoSub$hdl <- NULL
phenoSub$ldl <- NULL
phenoSub$tg <- NULL
phenoSub$CAD <- NULL

#Rename columns to match names necessary for GWAS() function
phenoSub <- rename(phenoSub, replace = c(FamID='id'))
#Include only subjects with hdl data
phenoSub <- phenoSub[!is.na(phenoSub$phenotype),]

phenodata<- phenoSub
genodata<- genodata[as.character(phenodata$id),]



cat(nrow(phenoSub),'subjects contain hdl data and will be used for GWAS. \n')

print(head(phenoSub))


                                                         