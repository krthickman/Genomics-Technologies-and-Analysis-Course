#---globals---
#customize for file locations if you have changed any names

#data input and output directories set
data.dir <- "./GWASTutorial_Files"
out.dir <- "./GWAS_out"

# Input files
gwas.fn <- lapply(c(bed='bed', bim='bim',fam='fam',gds='gds'), function(n) sprintf("%s/GWAStutorial.%s",data.dir,n))
clinical.fn <- sprintf('%s/GWAStutorial_clinical.csv',data.dir)
onethou.fn = lapply(c(info='info', ped='ped'),function(n) sprintf('./GWASTutorial_Files/chr16_1000g_CEU.%s', n))
protein.coding.coord.fname <- sprintf('%s/ProCodgene_coords.csv', data.dir)

# Output files
gwaa.fname <- sprintf('%s/GWAStutorial.out.txt', out.dir)
gwaa.unadj.fname <- sprintf("%s/GWAStutorialoutUnadj.txt", out.dir)
impute.out.fname <- sprintf("%s/GWAStutorial_imputationOut.csv", out.dir)
CETP.fname <- sprintf('%s/CETP_GWASout.csv', out.dir)  