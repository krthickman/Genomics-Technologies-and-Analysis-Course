#--step 8 - Run GWAS analysis using parallel processing

library(plyr)
library(parallel)
source('./GWAA.R')

SNPs_sub <-genoBim$SNP[genoBim$chr==15 | genoBim$chr==16 | genoBim$chr==17]
genodata_sub <- genodata[,colnames(genodata)%in%SNPs_sub]

nSNPs <- ncol(genodata_sub)
nSplits <-10

genosplit <- ceiling(nSNPs/nSplits) # number of SNPs in each subset
snp.start <- seq(1, nSNPs, genosplit) # index of first SNP in group
snp.stop <- pmin(snp.start+genosplit-1, nSNPs) # index of last SNP in group

#Note: This function writes a file, but does not produce an R object
start<- Sys.time()

GWAA(genodata_sub, phenodata, filename="GWAA.txt")

end <- Sys.time()

print(end-start)