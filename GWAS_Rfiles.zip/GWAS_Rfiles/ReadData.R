#---Step 1 - Read Data into R----

library(snpStats)

#Read in PLINK files to create list of SNPs
geno<- read.plink(gwas.fn$bed, gwas.fn$bim, gwas.fn$fam, na.strings=('-9'))

#obtain genotype SnpMatrix object from generated list
# Note: Phenotypes and covariates will be read from clinical data file in another step.

genotype<- geno$genotype
print(genotype)

#Obtain SNP information table from list
genoBim <- geno$map
colnames(genoBim) <- c("chr",'SNP', 'gen.dist', 'position', 'A1', 'A2')
print(head(genoBim))

#remove raw file to open up memory
rm(geno)

# Read in clincial data---

clinical <- read.csv(clinical.fn, colClasses = c('character','factor','factor',rep('numeric',4)))
rownames(clinical)<-clinical$FamID
print(head(clinical))
