#--- step 5- Hard-Weinberg SNP filtering
library(snpStats)
library(gdsfmt)

hardy<- 10^-6  #HWE cut-off

CADcontrols<- clinical[clinical$CAD==0, 'FamID']
snpsum.colCont <- col.summary(genotype[CADcontrols, ])
HWEuse<- with(snpsum.colCont, !is.na(z.HWE)&(abs(z.HWE)<abs(qnorm(hardy/2))))
rm(snpsum.colCont)

HWEuse[is.na(HWEuse)]<- FALSE  #remove NAs
cat(ncol(genotype)-sum(HWEuse),'SNPs will be removed due to highe HWE. \n')

#subset genotype and SNP summary data for SNPs that pass HWE criteria
genotype<- genotype[,HWEuse]

print(genotype)

