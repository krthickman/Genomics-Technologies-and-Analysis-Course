#--step 11 -- Visualization of Data

source("GWAS_ManhattanFunction.R")
par=mfrow=c(1,1)

#Create Manhattan Plot
GWAS_Manhattan(GWAScomb)