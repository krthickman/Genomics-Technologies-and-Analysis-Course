#--step 12-- LD Heat map
#biocLite('LDheatmap')
#biocLite('rtracklayer')
#biocLite("ggplot2")
library(LDheatmap)
library(rtracklayer)
library(ggplot2)
library(snpStats)
library(plyr)
library(postgwas)

#Add 'rs247617' to CETP
CETP <- rbind.fill(GWASout[GWASout$SNP == 'rs247617', ],CETP)

#combine genotypes and imputed genotypes for CETP region
subgen <- cbind(genotype[ ,colnames(genotype) %in% CETP$SNP], impCETPgeno)

#Subset SNPs for only centrain genotypes
certain <- apply(as(subgen, 'numeric'),2,function(x){all(x %in% c(0,1,2,NA))})
subgen <- subgen[ ,certain]

#subset and order CETP SNPs by position
CETP<- CETP[CETP$SNP %in% colnames(subgen), ]
CETP <- arrange(CETP, position)
subgen <- subgen[ ,order(match(colnames(subgen),CETP$SNP))]

# Create LDheatmap
ld <- ld(subgen, subgen, stats='R.squared') #Find LD map of CETP SNPs

ll <- LDheatmap(ld, CETP$position, flip = TRUE, name='myLDgrob', title = NULL)

#Add genes, recombination
llplusgenes <- LDheatmap.addGenes(ll, chr= 'chr16', genome = 'hg19', genesLocation = 0.01)

# Add plot of -log(p)


plot.new()
llQplot2<- LDheatmap.addGrob(llplusgenes, rectGrob(gp=gpar(col="white")),height = .34)
pushViewport(viewport(x=0.483, y=0.76, width = 0.5, height = 0.4))

grid.draw(ggplotGrob({
  qplot(position,Neg_logP, data=CETP, xlab='', ylab='Negative log p-value', xlim=range(CETP$position),
        asp=1/10, color=factor(type), color=c('#000000', '#D55E00'))+
    theme(axis.text.x=element_blank(),
          axis.title.y=element_text(size=rel(0.75)),legend.position='none',
          axis.line=element_line(colour = 'black'))+
    scale_color_manual(values=c('red','black'))
}))
