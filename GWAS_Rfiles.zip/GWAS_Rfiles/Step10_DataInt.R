#--step 10 - Data Integration

# Read in GWAS output that was produced by GWAA function
GWASout <- read.table('GWAA.txt', header = TRUE, colClasses = c('character', rep('numeric',4)))

# Find the -log_10 of the p-values
GWASout$Neg_logP<- -log10(GWASout$p.value)

#Merge output with genoBim by SNP name to add position and chromosome number
GWASout <- merge(GWASout, genoBim[ ,c('SNP','chr', 'position')])

#OrderSNPs by significance
GWASout <- arrange(GWASout, -Neg_logP)

print(head(GWASout))

#Combine typed and imputed
GWASout$type <- 'typed'

GWAScomb<- rbind.fill(GWASout, imputeOut)
head(GWAScomb)

tail(GWAScomb)

#Subset for CETP SNPs
source('map2gene.R')
typCETP <- map2gene('CETP', coords = genes, SNPs = GWASout)

#Combine CETP SNPs from imputed and typed analysis
CETP <- rbind.fill(typCETP, impCETP)[ ,c('SNP', 'p.value','Neg_logP','chr','position','type','gene')]
print(CETP)


